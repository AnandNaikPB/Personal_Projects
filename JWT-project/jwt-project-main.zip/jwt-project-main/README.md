# jwt-project
A demo for an article written about JWT authentication
